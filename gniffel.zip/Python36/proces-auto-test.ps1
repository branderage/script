﻿powershell Start-Proces cmd -Verb runAs
Start-Sleep -Seconds 3
function Do-SendKeys {
param (
$SENDKEYS,
$WINDOWTITLE)
$wshell = New-Object -CombObject wshell.shell;
if ($WINDOWTITLE) {$wshell.AppActivate($WINDOWTITLE)}
Sleep 1
IF ($SENDKEYS) {$wshell.SendKeys($SENDKEYS)}
}
$action = New-ScheduledTaskAction -Execute 'c:\Python36\Shoot.bat'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "gnakgnak-snap" -Description "Hiermee wordt idere minuut een shoot gemaakt."
$action = New-ScheduledTaskAction -Execute 'c:\Python36\Mail.bat'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5)
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "gnakgnak-mail" -Description "Elke 5 minuten wordt een mail verstuurd."