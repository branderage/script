﻿$action = New-ScheduledTaskAction -Execute 'c:\Python36\Shoot.bat'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "gnakgnak" -Description "This is a test task. Its job is to start shoot every 1 minutes."
$action = New-ScheduledTaskAction -Execute 'c:\Python36\Mail.bat'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5)
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "gnakgnak" -Description "This is a test task. Its job is to start mail every 5 minutes."